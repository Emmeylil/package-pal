import Root from "./skeleton.svelte";

export {
	Root,
	//
	Root as Skeleton,
};
