import Root from "./toggle.svelte";
export {
	toggleVariants,
	type ToggleSize,
	type ToggleVariant,
	type ToggleVariants,
} from "./toggle.svelte";

export {
	Root,
	//
	Root as Toggle,
};
