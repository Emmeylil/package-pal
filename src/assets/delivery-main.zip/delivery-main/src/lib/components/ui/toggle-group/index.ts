import Root from "./toggle-group.svelte";
import Item from "./toggle-group-item.svelte";

export {
	Root,
	Item,
	//
	Root as ToggleGroup,
	Item as ToggleGroupItem,
};
