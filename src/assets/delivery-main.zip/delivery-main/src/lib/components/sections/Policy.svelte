<script>
	// You can add any logic or data here if necessary
</script>

<div class="p-4">
	<h2 class="my-2 text-xl font-bold">
		A- Return Policy & Holding and Confiscation Time for Packages
	</h2>

	<p class="mb-2">
		The recipient has <strong>7 calendar days</strong> to pick up their package at the destination
		Hub. If not collected, the package will be returned to the original Hub where it is available
		for sender pickup for <strong>7 calendar days</strong>. If the sender does not collect within
		this time, it will be transferred to our main warehouse and held for sender pickup for an
		additional <strong>14 calendar days</strong>. This provides the sender a total
		<strong>21-day</strong> collection window after return.
	</p>

	<p class="mb-2">
		At the end of this period, any unclaimed package will be considered abandoned and will become
		the property of Jumia.
	</p>

	<h2 class="my-2 text-xl font-bold">Shipping Rules</h2>
	<p class="mb-2">
		Jumia agencies may refuse items deemed fragile or poorly packaged, as well as any oversized
		packages.
	</p>
	<p class="mb-2">
		Prohibited items include hazardous materials, animals (alive or dead), cash, drugs, firearms,
		etc.
	</p>
	<p class="mb-2">
		<strong>Important:</strong> No compensation will be provided for prohibited shipments, and the sender
		may be held liable.
	</p>

	<h2 class="my-2 text-xl font-bold">B- Claims and Compensation</h2>

	<p class="mb-2">
		1) When you choose an enhanced level of insurance coverage (Premium Protection) for your package
		and upon payment of the relevant additional charges per section 5.7 and 6.10 of our <a
			href="https://www.jumia.com.ng/sp-term-condition-jumia-delivery/"
			target="_blank">General Conditions of Use</a
		>, in case of loss of your package, Jumia will compensate you for the value of the item, that
		is, the lowest between the declared value, and the value of the same item on our Jumia platform.
		However, you shall be entitled to a maximum compensation of 75% of the item’s value, if the
		package is returned to the point of origin damaged and considering the reconstitution or
		reconstruction value.
	</p>
	<p class="mb-2">
		2) You shall only be entitled to a compensation of two times (2X) the value of the shipping fee
		for packages without Premium Protection, in case of loss, or damage and return to the point of
		origin
	</p>
	<p class="mb-2">
		3) The compensation limit for an individual Package whether or not with Premium Protection is
		₦500,000.00 (Five Hundred Thousand Naira) only. This compensation is limit may be modified by
		Jumia from time to time at its discretion, or otherwise notified to the Customer as defined in
		the <a href="https://www.jumia.com.ng/sp-term-condition-jumia-delivery/" target="_blank"
			>General Conditions of Use</a
		>. For any complaints, please contact us via our customer service.
	</p>

	<h2 class="my-2 text-xl font-bold">C- License Message and Customer Service Contact</h2>

	<p class="mb-2">Licensed operator for the shipment of national postal services by NIPOST.</p>

	<p class="mb-2"><strong>For any claims, please call customer service.</strong></p>

	<ul class="list-disc pl-6">
		<li>02018881106</li>
		<li>
			<a href="https://www.jumia.com.ng/sp-term-condition-jumia-delivery/" target="_blank"
				>See our General Conditions of Use</a
			>
		</li>
	</ul>
</div>
