<script>
	// Services with images
	const services = [
		{
			title: 'Express Delivery',
			description: 'Fast and reliable delivery within Lagos and other major cities.',
			image:
				'https://ng.jumia.is/cms/external/cms/sp-jumia-delivery_en_NG/473e7e8ecb5df59dcae18b74b8103e63.jpg'
		},
		{
			title: 'Nationwide Shipping',
			description: 'We offer nationwide shipping, delivering parcels across all states.',
			image:
				'https://ng.jumia.is/cms/external/cms/sp-jumia-delivery_en_NG/573c3c452f6534341a6990e9d3d12827.jpg'
		},
		{
			title: 'Reliable Fleet',
			description:
				'One of the largest delivery fleets in Nigeria to ensure quick and safe delivery.',
			image:
				'https://ng.jumia.is/cms/external/cms/sp-jumia-delivery_en_NG/0667cbdbc0c063b866aa2f2d34e06437.jpg'
		}
	];

	// Additional feature blocks
	const features = [
		{
			title: 'Affordable Prices',
			description:
				'Get the best value for your money with our transparent and affordable parcel delivery rates.'
		},
		{
			title: 'Track Your Parcel',
			description:
				'Once your item is on the move, you can follow its journey in real-time. We keep you in the loop every step of the way.'
		},
		{
			title: 'Built For Any Business',
			description:
				'If you run a business (big or small) Jumia Delivery has your back. We offer solutions that grow with you, including Pay on Delivery, bulk shipping, and more.'
		}
	];
</script>

<!-- Section Title -->
<div class="mb-6 text-center">
	<h2 class="text-3xl font-bold text-orange-600">Why people choose Jumia Delivery?</h2>
</div>

<!-- First Row: Image-based services -->
<div class="flex flex-wrap justify-center gap-6 p-5">
	{#each services as service}
		<div class="w-64 flex-none rounded-lg bg-gray-100 p-4 text-center shadow-md">
			<img src={service.image} alt={service.title} class="h-40 w-full rounded-lg object-cover" />
			<h3 class="mt-3 text-xl font-bold text-orange-600">{service.title}</h3>
			<p class="mt-2 text-gray-700">{service.description}</p>
		</div>
	{/each}
</div>

<!-- Second Row: Text-only features -->
<div class="flex flex-wrap justify-center gap-6 px-5 pb-10">
	{#each features as feature}
		<div
			class="w-64 flex-none rounded-lg border border-gray-200 bg-white p-4 text-center shadow-md"
		>
			<h3 class="text-lg font-semibold text-orange-600">{feature.title}</h3>
			<p class="mt-2 text-sm text-gray-700">{feature.description}</p>
		</div>
	{/each}
</div>
