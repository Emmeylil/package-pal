<script>
	const services = [
		{
			title: 'Nationwide Parcel Delivery',
			description:
				'Send anything to any of Nigeria’s 36 states and the FCT. Small or large, we’ll move it across the country without stress.'
		},
		{
			title: 'For Businesses & Online Sellers',
			description:
				'Running an online store? Selling on WhatsApp or Instagram? Let us handle your deliveries while you focus on growing.'
		}
	];
</script>

<section class="section">
	<h2 class="text-3xl font-bold text-orange-600">Our Services – Built Around You</h2>
	<div class="services">
		{#each services as service}
			<div class="card">
				<h3>{service.title}</h3>
				<p>{service.description}</p>
			</div>
		{/each}
	</div>
</section>

<style>
	.section {
		padding: 2rem;
		max-width: 1200px;
		margin: 0 auto;
	}

	.services {
		display: flex;
		flex-wrap: wrap;
		gap: 1.5rem;
		justify-content: space-between;
	}

	.card {
		flex: 1 1 300px;
		background: #f9f9f9;
		padding: 1.5rem;
		border-radius: 1rem;
		box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
		transition: transform 0.2s;
	}

	.card:hover {
		transform: translateY(-4px);
	}

	h2 {
		margin-bottom: 1.5rem;
		text-align: center;
	}
	h3 {
		margin-bottom: 0.75rem;
		font-size: 1.25rem;
		color: #222;
	}

	p {
		color: #555;
		line-height: 1.5;
	}
</style>
