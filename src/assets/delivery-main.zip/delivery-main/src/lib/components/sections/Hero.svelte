<script>
	let title = 'Jumia Delivery: Fast, Reliable & Affordable Parcel Delivery Across Nigeria.';
	let description = `Wherever you are in Nigeria, from Lagos to Kano, we’re here to help you send parcels quickly and safely. Jumia Delivery is open to everyone, whether you're a business owner or just sending something to a friend or family.`;
</script>

<div class="flex items-center justify-center">
	<div class="mx-auto w-full max-w-2xl rounded-lg bg-gray-100 p-6 text-center shadow-md">
		<!-- Image Section -->
		<img
			src="https://ng.jumia.is/cms/0-1-initiatives/jumia-services/2025/CI_W26_LP_Jumia_Colis_Express_C2C-1500x350_NG.jpg"
			alt="Jumia Delivery Service"
			class="mb-4 h-auto w-full rounded-lg"
		/>

		<!-- Text Content Section -->
		<h2 class="text-xl font-bold text-orange-500">{title}</h2>
		<p class="mt-2 text-gray-700">{description}</p>
	</div>
</div>
