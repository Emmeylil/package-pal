export enum Constants {
    TRACKING = 'https://packagetracker-services.jumia.com/#/NG/en/package/tracking/'
}