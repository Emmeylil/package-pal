<script lang="ts">
	import PusList from '$lib/components/lists/PusList.svelte';
	import Deliveryzone from '$lib/components/sections/Deliveryzone.svelte';
	import Header from '$lib/components/sections/Header.svelte';
	import Hero from '$lib/components/sections/Hero.svelte';
	import Howtoship from '$lib/components/sections/Howtoship.svelte';
	import Builtaroundus from '$lib/components/sections/Builtaroundus.svelte';
	import Map from '$lib/components/sections/Map.svelte';
	import Ourservices from '$lib/components/sections/Ourservices.svelte';
	import Policy from '$lib/components/sections/Policy.svelte';
	import Pricelist from '$lib/components/sections/Pricelist.svelte';
	import Faq from '$lib/components/sections/FAQ.svelte';
	import type { PageData } from './$types';

	let { data }: { data: PageData } = $props();
	const remoteData = data.remoteData;
</script>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<title>Jumia Delivery - Fast, Reliable Shipping in Nigeria</title>
		<script type="application/ld+json">
			{
				"@context": "https://schema.org",
				"@type": "Service",
				"name": "Jumia Delivery",
				"description": "Jumia Delivery is a reliable and affordable parcel delivery and shipping service in Nigeria, offering express delivery within Lagos and nationwide shipping across 36 states. With options for various package sizes, real-time tracking, and comprehensive logistics solutions, Jumia Delivery aims to provide seamless e-commerce fulfillment.",
				"serviceType": "E-commerce Logistics; Parcel Delivery; Shipping Service",
				"provider": {
					"@type": "Organization",
					"name": "Jumia",
					"url": "https://www.jumia.com.ng/",
					"logo": "https://www.jumia.com.ng/assets_cms/images/jm_logo_white.png"
				},
				"areaServed": {
					"@type": "Country",
					"name": "Nigeria"
				},
				"url": "https://www.jumia.com.ng/sp-jumia-delivery/",
				"image": "https://www.jumia.com.ng/assets_cms/images/delivery-hero-img.png"
			}
		</script>
	</head>
	<body> </body>
</html>

{#await remoteData}
	<div class="flex flex-col gap-4 p-4">
		<Header />
		<Hero />
		<Ourservices />
		<Builtaroundus />
		<div class="grid grid-cols-1 gap-4 md:grid-cols-[276px_1fr]">
			<div>Loading...</div>

			<Map />
		</div>

		<Howtoship />
		<Pricelist />
		<Deliveryzone />
		<Policy />
		<Faq />
	</div>
{:then value}
	{@const { pus, priceList, zones } = value}
	<div class="flex flex-col gap-4 p-4">
		<Header />
		<Hero />
		<Ourservices />
		<Builtaroundus />
		<div class="grid grid-cols-1 gap-4 md:grid-cols-[276px_1fr]">
			<PusList items={pus} />

			<Map />
		</div>

		<Howtoship />
		<Pricelist {priceList} />

		<Deliveryzone {zones} />
		<Policy />
		<Faq />
	</div>
{/await}
